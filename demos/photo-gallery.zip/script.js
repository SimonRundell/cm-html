document.addEventListener('DOMContentLoaded', function () {

  const likeButtons = document.querySelectorAll('.like-btn');

  likeButtons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const isLiked = btn.dataset.liked === 'true';

      if (isLiked) {
        btn.dataset.liked = 'false';
        btn.textContent = '♡ Like';
        btn.classList.remove('liked');
      } else {
        btn.dataset.liked = 'true';
        btn.textContent = '♥ Liked';
        btn.classList.add('liked');
      }
    });
  });

});
